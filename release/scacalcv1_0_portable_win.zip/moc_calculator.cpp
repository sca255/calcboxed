/****************************************************************************
** Meta object code from reading C++ file 'calculator.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../calculator/calculator.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'calculator.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASScalculatorENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASScalculatorENDCLASS = QtMocHelpers::stringData(
    "calculator",
    "add_1_l1",
    "",
    "add_2_l1",
    "add_3_l1",
    "add_4_l1",
    "add_5_l1",
    "add_6_l1",
    "add_7_l1",
    "add_8_l1",
    "add_9_l1",
    "add_0_l1",
    "add_plus_l1",
    "add_minus_l1",
    "add_div_l1",
    "add_mul_l1",
    "equal",
    "app_sqrt",
    "app_cbrt",
    "app_pow",
    "add_mod_l1",
    "clear",
    "back"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASScalculatorENDCLASS_t {
    uint offsetsAndSizes[46];
    char stringdata0[11];
    char stringdata1[9];
    char stringdata2[1];
    char stringdata3[9];
    char stringdata4[9];
    char stringdata5[9];
    char stringdata6[9];
    char stringdata7[9];
    char stringdata8[9];
    char stringdata9[9];
    char stringdata10[9];
    char stringdata11[9];
    char stringdata12[12];
    char stringdata13[13];
    char stringdata14[11];
    char stringdata15[11];
    char stringdata16[6];
    char stringdata17[9];
    char stringdata18[9];
    char stringdata19[8];
    char stringdata20[11];
    char stringdata21[6];
    char stringdata22[5];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASScalculatorENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASScalculatorENDCLASS_t qt_meta_stringdata_CLASScalculatorENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "calculator"
        QT_MOC_LITERAL(11, 8),  // "add_1_l1"
        QT_MOC_LITERAL(20, 0),  // ""
        QT_MOC_LITERAL(21, 8),  // "add_2_l1"
        QT_MOC_LITERAL(30, 8),  // "add_3_l1"
        QT_MOC_LITERAL(39, 8),  // "add_4_l1"
        QT_MOC_LITERAL(48, 8),  // "add_5_l1"
        QT_MOC_LITERAL(57, 8),  // "add_6_l1"
        QT_MOC_LITERAL(66, 8),  // "add_7_l1"
        QT_MOC_LITERAL(75, 8),  // "add_8_l1"
        QT_MOC_LITERAL(84, 8),  // "add_9_l1"
        QT_MOC_LITERAL(93, 8),  // "add_0_l1"
        QT_MOC_LITERAL(102, 11),  // "add_plus_l1"
        QT_MOC_LITERAL(114, 12),  // "add_minus_l1"
        QT_MOC_LITERAL(127, 10),  // "add_div_l1"
        QT_MOC_LITERAL(138, 10),  // "add_mul_l1"
        QT_MOC_LITERAL(149, 5),  // "equal"
        QT_MOC_LITERAL(155, 8),  // "app_sqrt"
        QT_MOC_LITERAL(164, 8),  // "app_cbrt"
        QT_MOC_LITERAL(173, 7),  // "app_pow"
        QT_MOC_LITERAL(181, 10),  // "add_mod_l1"
        QT_MOC_LITERAL(192, 5),  // "clear"
        QT_MOC_LITERAL(198, 4)   // "back"
    },
    "calculator",
    "add_1_l1",
    "",
    "add_2_l1",
    "add_3_l1",
    "add_4_l1",
    "add_5_l1",
    "add_6_l1",
    "add_7_l1",
    "add_8_l1",
    "add_9_l1",
    "add_0_l1",
    "add_plus_l1",
    "add_minus_l1",
    "add_div_l1",
    "add_mul_l1",
    "equal",
    "app_sqrt",
    "app_cbrt",
    "app_pow",
    "add_mod_l1",
    "clear",
    "back"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASScalculatorENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  140,    2, 0x0a,    1 /* Public */,
       3,    0,  141,    2, 0x0a,    2 /* Public */,
       4,    0,  142,    2, 0x0a,    3 /* Public */,
       5,    0,  143,    2, 0x0a,    4 /* Public */,
       6,    0,  144,    2, 0x0a,    5 /* Public */,
       7,    0,  145,    2, 0x0a,    6 /* Public */,
       8,    0,  146,    2, 0x0a,    7 /* Public */,
       9,    0,  147,    2, 0x0a,    8 /* Public */,
      10,    0,  148,    2, 0x0a,    9 /* Public */,
      11,    0,  149,    2, 0x0a,   10 /* Public */,
      12,    0,  150,    2, 0x0a,   11 /* Public */,
      13,    0,  151,    2, 0x0a,   12 /* Public */,
      14,    0,  152,    2, 0x0a,   13 /* Public */,
      15,    0,  153,    2, 0x0a,   14 /* Public */,
      16,    0,  154,    2, 0x0a,   15 /* Public */,
      17,    0,  155,    2, 0x0a,   16 /* Public */,
      18,    0,  156,    2, 0x0a,   17 /* Public */,
      19,    0,  157,    2, 0x0a,   18 /* Public */,
      20,    0,  158,    2, 0x0a,   19 /* Public */,
      21,    0,  159,    2, 0x0a,   20 /* Public */,
      22,    0,  160,    2, 0x0a,   21 /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject calculator::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASScalculatorENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASScalculatorENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASScalculatorENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<calculator, std::true_type>,
        // method 'add_1_l1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'add_2_l1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'add_3_l1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'add_4_l1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'add_5_l1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'add_6_l1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'add_7_l1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'add_8_l1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'add_9_l1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'add_0_l1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'add_plus_l1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'add_minus_l1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'add_div_l1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'add_mul_l1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'equal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'app_sqrt'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'app_cbrt'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'app_pow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'add_mod_l1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'clear'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'back'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void calculator::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<calculator *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->add_1_l1(); break;
        case 1: _t->add_2_l1(); break;
        case 2: _t->add_3_l1(); break;
        case 3: _t->add_4_l1(); break;
        case 4: _t->add_5_l1(); break;
        case 5: _t->add_6_l1(); break;
        case 6: _t->add_7_l1(); break;
        case 7: _t->add_8_l1(); break;
        case 8: _t->add_9_l1(); break;
        case 9: _t->add_0_l1(); break;
        case 10: _t->add_plus_l1(); break;
        case 11: _t->add_minus_l1(); break;
        case 12: _t->add_div_l1(); break;
        case 13: _t->add_mul_l1(); break;
        case 14: _t->equal(); break;
        case 15: _t->app_sqrt(); break;
        case 16: _t->app_cbrt(); break;
        case 17: _t->app_pow(); break;
        case 18: _t->add_mod_l1(); break;
        case 19: _t->clear(); break;
        case 20: _t->back(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *calculator::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *calculator::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASScalculatorENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int calculator::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 21;
    }
    return _id;
}
QT_WARNING_POP
